# FollowUp AI
Never Lose a Client Again.

## Démarrage
1. `cp .env.example .env.local` puis remplir les valeurs Supabase
2. `npm install`
3. `npm run dev` puis ouvrir http://localhost:3000
