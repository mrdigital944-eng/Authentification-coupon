# FollowUp AI : architecture

- Front et API : Next.js 14 (App Router), TypeScript, Tailwind
- Données et auth : Supabase (PostgreSQL + RLS)
- Hébergement : Vercel ; versionnement : GitHub
- Relances : tâches stockées en base, envoi par cron serveur (Vercel Cron / Supabase pg_cron)
- IA : route serveur unique, clé via AI_API_KEY, modèles prédéfinis en repli
- Rôles : owner / admin / member (table memberships) ; admin plateforme via profiles.role
- Étapes : 1 init, 2 UI publique, 3 auth+DB, 4 dashboard, 5 prospects/clients, 6 relances, 7 IA, 8 notifications, 9 abonnements, 10 tests/sécurité, 11 déploiement

## Étape 2
- i18n FR/EN : cookie `lang`, dictionnaire dans src/lib/i18n.ts
- Formulaires d'authentification déjà reliés à Supabase Auth ; /reset-password et la protection des routes arrivent à l'étape 3

## Étape 3
- Migration SQL : supabase/migrations/0001_init.sql (tables, index, RLS, fonctions is_member / is_platform_admin)
- Création automatique profil + entreprise + abonnement FREE à l'inscription (trigger handle_new_user)
- Limite FREE de 5 prospects imposée par trigger SQL (pas seulement côté interface)
- Factures multi-devises : table invoices (currency ISO 4217 par facture)
- Middleware : protège /dashboard, /prospects, /clients, etc. ; profil suspendu déconnecté dans le layout privé
- Paiements et abonnements : écriture réservée au serveur (service role), aucune politique d'écriture côté client

## Étape 4
- Tableau de bord : indicateurs calculés côté serveur depuis la base (RLS appliquée), graphiques en SVG sans dépendance
- Les montants restent par devise (aucune conversion de change inventée)
- « Relances du jour / en retard » calculées selon le fuseau du profil (profiles.timezone)
- Données de démo : supabase/seed_demo.sql (dev uniquement)
