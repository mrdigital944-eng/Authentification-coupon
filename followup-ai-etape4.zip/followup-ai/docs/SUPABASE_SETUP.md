# Configuration Supabase (étape 3)

1. Créez un compte gratuit sur supabase.com puis un nouveau projet (choisissez la région la plus proche de vos utilisateurs).
2. Menu **SQL Editor** > New query : collez tout le contenu de `supabase/migrations/0001_init.sql` > Run.
3. Menu **Project Settings > API** : copiez l'URL du projet et la clé `anon public`.
4. Dans `.env.local` : renseignez `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Ne partagez jamais la clé `service_role`.
5. Menu **Authentication > URL Configuration** :
   - Site URL : `http://localhost:3000` (puis votre URL Vercel en production)
   - Redirect URLs : `http://localhost:3000/auth/callback` (et l'équivalent en production)
6. Test : inscrivez-vous sur /signup, confirmez l'email, connectez-vous : vous arrivez sur /dashboard.
7. Pour vous donner le rôle administrateur (après votre inscription), dans le SQL Editor :
   `update profiles set role = 'admin' where id = (select id from auth.users where email = 'VOTRE_EMAIL');`

Note : l'envoi d'emails par défaut de Supabase est limité en volume. Pour la production, configurez un SMTP (étape 8).
