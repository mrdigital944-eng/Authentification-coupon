import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

const PROTECTED = ["/dashboard", "/prospects", "/clients", "/followups", "/invoices", "/templates", "/assistant", "/notifications", "/settings", "/billing", "/admin"];
const AUTH_PAGES = ["/login", "/signup", "/forgot-password"];

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  const isProtected = PROTECTED.some((p) => path === p || path.startsWith(p + "/"));
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  const toLogin = () => {
    const u = request.nextUrl.clone();
    u.pathname = "/login";
    u.search = isProtected ? `?next=${encodeURIComponent(path)}` : "";
    return NextResponse.redirect(u);
  };

  if (!url || !key) return isProtected ? toLogin() : NextResponse.next();

  let response = NextResponse.next({ request });
  const supabase = createServerClient(url, key, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll: (list) => {
        list.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        list.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });
  const { data: { user } } = await supabase.auth.getUser();

  if (isProtected && !user) return toLogin();
  if (user && AUTH_PAGES.includes(path)) {
    const u = request.nextUrl.clone();
    u.pathname = "/dashboard";
    u.search = "";
    return NextResponse.redirect(u);
  }
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|icon.svg|manifest.webmanifest|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
