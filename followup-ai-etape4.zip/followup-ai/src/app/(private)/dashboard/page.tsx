import { createClient } from "@/lib/supabase/server";
import { getLang, t } from "@/lib/i18n";
import { dayBounds, lastMonths } from "@/lib/dates";
import { money, sumByCurrency } from "@/lib/format";
import { LEAD_STATUSES, PENDING_STATUSES, type LeadStatus } from "@/lib/status";
import { StatCard } from "@/components/dashboard/StatCard";
import { StatusChart } from "@/components/dashboard/StatusChart";
import { MonthlyChart } from "@/components/dashboard/MonthlyChart";

type LeadRow = { status: LeadStatus; estimated_value: number | null; currency: string; created_at: string };

export default async function Dashboard() {
  const supabase = createClient();
  const lang = getLang();
  const d = t(lang).app;
  const locale = lang === "fr" ? "fr-FR" : "en-US";

  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from("profiles").select("full_name, timezone").eq("id", user!.id).single();
  const { start, end, todayStr } = dayBounds(profile?.timezone ?? "UTC");

  const [leadsRes, clientsRes, tasksRes, invoicesRes] = await Promise.all([
    supabase.from("leads").select("status, estimated_value, currency, created_at").limit(5000),
    supabase.from("clients").select("id", { count: "exact", head: true }),
    supabase.from("tasks").select("id, title, due_at").eq("status", "pending").lt("due_at", end.toISOString()).order("due_at").limit(50),
    supabase.from("invoices").select("amount, currency").in("status", ["sent", "overdue"]).lt("due_date", todayStr),
  ]);

  const leads = (leadsRes.data ?? []) as LeadRow[];
  const tasks = tasksRes.data ?? [];
  const overdueTasks = tasks.filter((x) => new Date(x.due_at) < start);
  const todayTasks = tasks.filter((x) => new Date(x.due_at) >= start);

  const counts = Object.fromEntries(LEAD_STATUSES.map((s) => [s, 0])) as Record<LeadStatus, number>;
  for (const l of leads) counts[l.status] += 1;
  const total = leads.length;
  const pending = PENDING_STATUSES.reduce((n, s) => n + counts[s], 0);
  const conversion = total ? Math.round((counts.converted / total) * 100) : 0;

  const pipeline = sumByCurrency(
    leads.filter((l) => PENDING_STATUSES.includes(l.status) && l.estimated_value).map((l) => ({ amount: Number(l.estimated_value), currency: l.currency }))
  );
  const unpaid = sumByCurrency((invoicesRes.data ?? []).map((i) => ({ amount: Number(i.amount), currency: i.currency })));
  const fmtList = (rows: { currency: string; amount: number }[]) =>
    rows.length ? rows.map((r) => <div key={r.currency} className="text-xl">{money(r.amount, r.currency, locale)}</div>) : <span className="text-xl text-night-700">{d.none}</span>;

  const months = lastMonths(6).map(({ key, date }) => ({
    label: date.toLocaleDateString(locale, { month: "short", timeZone: "UTC" }),
    value: leads.filter((l) => { const c = new Date(l.created_at); return `${c.getUTCFullYear()}-${c.getUTCMonth()}` === key; }).length,
  }));

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">{d.welcome}{profile?.full_name ? `, ${profile.full_name}` : ""}</h1>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label={d.totalLeads} value={total} />
        <StatCard label={d.clients} value={clientsRes.count ?? 0} />
        <StatCard label={d.pending} value={pending} />
        <StatCard label={d.conversion} value={`${conversion}%`} hint={d.conversionHint} tone="good" />
        <StatCard label={d.today} value={todayTasks.length} />
        <StatCard label={d.overdue} value={overdueTasks.length} tone={overdueTasks.length ? "warn" : "default"} />
        <StatCard label={d.pipeline} value={fmtList(pipeline)} hint={d.pipelineHint} />
        <StatCard label={d.overdueInvoices} value={fmtList(unpaid)} tone={unpaid.length ? "warn" : "default"} />
      </div>

      {total === 0 && <p className="rounded-card bg-white p-5 text-sm text-night-700 shadow-card">{d.empty}</p>}

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-card bg-white p-5 shadow-card">
          <h2 className="mb-4 font-semibold">{d.byStatus}</h2>
          <StatusChart counts={counts} labels={d.status} />
        </section>
        <section className="rounded-card bg-white p-5 shadow-card">
          <h2 className="mb-4 font-semibold">{d.perMonth}</h2>
          <MonthlyChart data={months} />
        </section>
      </div>

      <section className="rounded-card bg-white p-5 shadow-card">
        <h2 className="mb-3 font-semibold">{d.upcoming}</h2>
        {tasks.length === 0 ? (
          <p className="text-sm text-night-700">{d.noTasks}</p>
        ) : (
          <ul className="divide-y divide-night/5 text-sm">
            {tasks.slice(0, 8).map((x) => {
              const late = new Date(x.due_at) < start;
              return (
                <li key={x.id} className="flex items-center justify-between py-2.5">
                  <span>{x.title}</span>
                  <span className={late ? "font-medium text-rose-600" : "text-night-700"}>
                    {late ? `${d.late} · ` : ""}{new Date(x.due_at).toLocaleString(locale, { dateStyle: "short", timeStyle: "short", timeZone: profile?.timezone ?? "UTC" })}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
