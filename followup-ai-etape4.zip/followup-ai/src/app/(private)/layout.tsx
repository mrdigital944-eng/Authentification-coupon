import { redirect } from "next/navigation";
import Link from "next/link";
import { Logo } from "@/components/Logo";
import { LangSwitch } from "@/components/LangSwitch";
import { createClient } from "@/lib/supabase/server";
import { getLang, t } from "@/lib/i18n";

export default async function PrivateLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("suspended").eq("id", user.id).single();
  if (profile?.suspended) {
    await supabase.auth.signOut();
    redirect("/login?suspended=1");
  }

  const lang = getLang();
  const d = t(lang).app;
  return (
    <div className="min-h-screen">
      <header className="border-b border-night/5 bg-white">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <Link href="/dashboard"><Logo /></Link>
          <div className="flex items-center gap-3 text-sm">
            <LangSwitch lang={lang} />
            <form action="/auth/signout" method="post">
              <button className="rounded-card border border-night/10 px-3.5 py-2 hover:bg-mist">{d.logout}</button>
            </form>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-5 py-8">{children}</main>
    </div>
  );
}
