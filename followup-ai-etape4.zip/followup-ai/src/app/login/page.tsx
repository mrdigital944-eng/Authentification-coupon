import { Suspense } from "react";
import { PublicShell } from "@/components/PublicShell";
import { AuthForm } from "@/components/AuthForm";
import { getLang, t } from "@/lib/i18n";

export default function Page() {
  const labels = t(getLang()).auth as unknown as Record<string, string>;
  return (
    <PublicShell>
      <div className="flex justify-center px-5 py-16">
        <Suspense><AuthForm mode="login" labels={labels} /></Suspense>
      </div>
    </PublicShell>
  );
}
