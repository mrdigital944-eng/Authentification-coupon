import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { PricingGrid } from "@/components/PricingGrid";
import { getLang, t } from "@/lib/i18n";

export default function Home() {
  const d = t(getLang());
  return (
    <PublicShell>
      <section className="mx-auto max-w-4xl px-5 py-20 text-center sm:py-28">
        <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">{d.hero.title}</h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-night-700">{d.hero.sub}</p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link href="/signup" className="rounded-card bg-electric px-6 py-3 font-medium text-white shadow-card transition hover:bg-electric-600">{d.hero.cta}</Link>
          <Link href="/pricing" className="rounded-card border border-night/10 bg-white px-6 py-3 font-medium transition hover:bg-mist">{d.hero.cta2}</Link>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-5 px-5 pb-20 sm:grid-cols-2 lg:grid-cols-4">
        {d.features.map(([title, text]) => (
          <div key={title} className="rounded-card bg-white p-6 shadow-card">
            <h3 className="font-semibold">{title}</h3>
            <p className="mt-2 text-sm text-night-700">{text}</p>
          </div>
        ))}
      </section>
      <section className="mx-auto max-w-6xl px-5 pb-24">
        <h2 className="text-center text-3xl font-bold">{d.pricing.title}</h2>
        <p className="mb-10 mt-2 text-center text-night-700">{d.pricing.sub}</p>
        <PricingGrid />
      </section>
    </PublicShell>
  );
}
