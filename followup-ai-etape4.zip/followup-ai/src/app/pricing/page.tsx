import { PublicShell } from "@/components/PublicShell";
import { PricingGrid } from "@/components/PricingGrid";
import { getLang, t } from "@/lib/i18n";

export default function Pricing() {
  const d = t(getLang());
  return (
    <PublicShell>
      <div className="mx-auto max-w-6xl px-5 py-16">
        <h1 className="text-center text-4xl font-bold">{d.pricing.title}</h1>
        <p className="mb-10 mt-2 text-center text-night-700">{d.pricing.sub}</p>
        <PricingGrid />
      </div>
    </PublicShell>
  );
}
