import { redirect } from "next/navigation";
import { PublicShell } from "@/components/PublicShell";
import { ResetForm } from "@/components/ResetForm";
import { createClient } from "@/lib/supabase/server";
import { getLang, t } from "@/lib/i18n";

export default async function Page() {
  const { data: { user } } = await createClient().auth.getUser();
  if (!user) redirect("/forgot-password");
  const labels = t(getLang()).auth as unknown as Record<string, string>;
  return (
    <PublicShell>
      <div className="flex justify-center px-5 py-16"><ResetForm labels={labels} /></div>
    </PublicShell>
  );
}
