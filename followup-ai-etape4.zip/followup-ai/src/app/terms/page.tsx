import { PublicShell } from "@/components/PublicShell";
import { getLang, t } from "@/lib/i18n";

export default function Page() {
  const d = t(getLang()).legal;
  return (
    <PublicShell>
      <article className="mx-auto max-w-2xl space-y-4 px-5 py-16">
        <h1 className="text-3xl font-bold">{d.termsTitle}</h1>
        {d.terms.map((p) => <p key={p} className="text-night-700">{p}</p>)}
      </article>
    </PublicShell>
  );
}
