"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/client";

type Mode = "login" | "signup" | "forgot";
type Labels = Record<string, string>;

export function AuthForm({ mode, labels }: { mode: Mode; labels: Labels }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const params = useSearchParams();
  const suspended = params.get("suspended") === "1";

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const schema = z.object({
      email: z.string().email(),
      password: mode === "forgot" ? z.string().optional() : z.string().min(8, labels.minPwd),
    });
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) {
      setMsg({ type: "err", text: parsed.error.issues[0].message });
      return;
    }
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      setMsg({ type: "err", text: labels.errConfig });
      return;
    }
    setBusy(true);
    try {
      const sb = createClient();
      const origin = window.location.origin;
      if (mode === "login") {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setMsg({ type: "ok", text: labels.loginOk });
        const next = params.get("next");
        router.push(next && next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard");
        router.refresh();
      } else if (mode === "signup") {
        const { error } = await sb.auth.signUp({
          email,
          password,
          options: { data: { full_name: name }, emailRedirectTo: `${origin}/auth/callback` },
        });
        if (error) throw error;
        setMsg({ type: "ok", text: labels.sentSignup });
      } else {
        const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: `${origin}/auth/callback?next=/reset-password` });
        if (error) throw error;
        setMsg({ type: "ok", text: labels.sentForgot });
      }
    } catch {
      setMsg({ type: "err", text: labels.errGeneric });
    } finally {
      setBusy(false);
    }
  }

  const input = "w-full rounded-xl border border-night/10 bg-white px-3.5 py-2.5 text-sm outline-none focus:border-electric focus:ring-2 focus:ring-electric/20";
  const title = mode === "login" ? labels.login : mode === "signup" ? labels.signup : labels.forgot;
  const submit = mode === "login" ? labels.submitLogin : mode === "signup" ? labels.submitSignup : labels.submitForgot;

  return (
    <form onSubmit={onSubmit} className="w-full max-w-sm space-y-4 rounded-card bg-white p-7 shadow-card" noValidate>
      <h1 className="text-xl font-bold">{title}</h1>
      {mode === "signup" && (
        <label className="block space-y-1.5 text-sm">
          <span>{labels.name}</span>
          <input className={input} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
        </label>
      )}
      <label className="block space-y-1.5 text-sm">
        <span>{labels.email}</span>
        <input className={input} type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
      </label>
      {mode !== "forgot" && (
        <label className="block space-y-1.5 text-sm">
          <span>{labels.password}</span>
          <input className={input} type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} required />
        </label>
      )}
      {suspended && <p className="text-sm text-red-600" role="alert">{labels.suspended}</p>}
      {msg && <p className={`text-sm ${msg.type === "ok" ? "text-green-700" : "text-red-600"}`} role="status">{msg.text}</p>}
      <button disabled={busy} className="w-full rounded-card bg-electric px-4 py-2.5 text-sm font-medium text-white shadow-card transition hover:bg-electric-600 disabled:opacity-60">
        {submit}
      </button>
      <div className="space-y-1 text-center text-sm text-night-700">
        {mode === "login" && (<>
          <p><Link className="text-electric" href="/forgot-password">{labels.forgotLink}</Link></p>
          <p>{labels.noAccount} <Link className="text-electric" href="/signup">{labels.signup}</Link></p>
        </>)}
        {mode === "signup" && <p>{labels.haveAccount} <Link className="text-electric" href="/login">{labels.login}</Link></p>}
        {mode === "forgot" && <p><Link className="text-electric" href="/login">{labels.back}</Link></p>}
      </div>
    </form>
  );
}
