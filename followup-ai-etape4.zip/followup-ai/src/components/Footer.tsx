import Link from "next/link";
import { getLang, t } from "@/lib/i18n";

export function Footer() {
  const d = t(getLang());
  return (
    <footer className="border-t border-night/5 bg-white">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-6 text-sm text-night-700 sm:flex-row">
        <span>© {new Date().getFullYear()} FollowUp AI. {d.footer.rights}</span>
        <span className="flex gap-4">
          <Link href="/privacy" className="hover:text-electric">{d.footer.privacy}</Link>
          <Link href="/terms" className="hover:text-electric">{d.footer.terms}</Link>
        </span>
      </div>
    </footer>
  );
}
