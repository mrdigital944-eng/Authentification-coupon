import Link from "next/link";
import { Logo } from "./Logo";
import { LangSwitch } from "./LangSwitch";
import { getLang, t } from "@/lib/i18n";

export function Header() {
  const lang = getLang();
  const d = t(lang);
  return (
    <header className="sticky top-0 z-10 border-b border-night/5 bg-white/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Link href="/"><Logo /></Link>
        <nav className="flex items-center gap-3 text-sm">
          <Link href="/pricing" className="hidden px-2 text-night-700 hover:text-electric sm:block">{d.nav.pricing}</Link>
          <Link href="/login" className="px-2 text-night-700 hover:text-electric">{d.nav.login}</Link>
          <Link href="/signup" className="rounded-card bg-electric px-4 py-2 font-medium text-white shadow-card transition hover:bg-electric-600">{d.nav.signup}</Link>
          <LangSwitch lang={lang} />
        </nav>
      </div>
    </header>
  );
}
