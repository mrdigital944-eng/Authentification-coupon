"use client";
import { useRouter } from "next/navigation";

export function LangSwitch({ lang }: { lang: "fr" | "en" }) {
  const router = useRouter();
  const next = lang === "fr" ? "en" : "fr";
  return (
    <button
      onClick={() => {
        document.cookie = `lang=${next}; path=/; max-age=31536000; samesite=lax`;
        router.refresh();
      }}
      className="rounded-lg border border-night/10 px-2.5 py-1 text-xs font-medium uppercase hover:bg-white"
      aria-label={next === "en" ? "Switch to English" : "Passer en français"}
    >
      {next}
    </button>
  );
}
