export function LogoMark({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="16" fill="#0B1B3F" />
      <path d="M18 34c0-8.8 7.2-16 16-16h6" fill="none" stroke="#2563FF" strokeWidth="6" strokeLinecap="round" />
      <path d="M36 11l9 7-9 7" fill="none" stroke="#2563FF" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M22 40l7 7 15-16" fill="none" stroke="#fff" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo() {
  return (
    <span className="flex items-center gap-2 font-semibold tracking-tight">
      <LogoMark />
      <span className="text-lg">FollowUp <span className="text-electric">AI</span></span>
    </span>
  );
}
