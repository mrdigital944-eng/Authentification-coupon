import Link from "next/link";
import { PLANS } from "@/lib/plans";
import { getLang, t } from "@/lib/i18n";

export function PricingGrid() {
  const d = t(getLang());
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {PLANS.map((p) => {
        const hl = "highlight" in p && p.highlight;
        return (
          <div key={p.id} className={`flex flex-col rounded-card bg-white p-6 shadow-card ${hl ? "ring-2 ring-electric" : ""}`}>
            <h3 className="text-sm font-semibold tracking-wide text-electric">{p.id}</h3>
            <p className="mt-3 text-3xl font-bold">
              {p.price === 0 ? d.pricing.free : `$${p.price}`}
              {p.price > 0 && <span className="text-base font-normal text-night-700">{d.pricing.month}</span>}
            </p>
            <ul className="mt-5 flex-1 space-y-2 text-sm text-night-700">
              {d.plans[p.id].map((f) => (
                <li key={f} className="flex gap-2"><span className="text-electric">✓</span>{f}</li>
              ))}
            </ul>
            <Link href="/signup" className={`mt-6 rounded-card px-4 py-2.5 text-center text-sm font-medium transition ${hl ? "bg-electric text-white hover:bg-electric-600" : "border border-night/10 hover:bg-mist"}`}>
              {p.price === 0 ? d.pricing.start : d.pricing.choose}
            </Link>
          </div>
        );
      })}
    </div>
  );
}
