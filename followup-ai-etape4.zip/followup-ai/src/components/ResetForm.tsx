"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/client";

export function ResetForm({ labels }: { labels: Record<string, string> }) {
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = z.string().min(8, labels.minPwd).safeParse(password);
    if (!parsed.success) return setMsg({ type: "err", text: parsed.error.issues[0].message });
    setBusy(true);
    const { error } = await createClient().auth.updateUser({ password });
    setBusy(false);
    if (error) return setMsg({ type: "err", text: labels.errGeneric });
    setMsg({ type: "ok", text: labels.resetOk });
    setTimeout(() => router.push("/dashboard"), 1200);
  }

  return (
    <form onSubmit={onSubmit} className="w-full max-w-sm space-y-4 rounded-card bg-white p-7 shadow-card" noValidate>
      <h1 className="text-xl font-bold">{labels.newPassword}</h1>
      <input
        type="password" autoComplete="new-password" value={password}
        onChange={(e) => setPassword(e.target.value)} placeholder={labels.password}
        className="w-full rounded-xl border border-night/10 px-3.5 py-2.5 text-sm outline-none focus:border-electric focus:ring-2 focus:ring-electric/20"
      />
      {msg && <p className={`text-sm ${msg.type === "ok" ? "text-green-700" : "text-red-600"}`} role="status">{msg.text}</p>}
      <button disabled={busy} className="w-full rounded-card bg-electric px-4 py-2.5 text-sm font-medium text-white shadow-card hover:bg-electric-600 disabled:opacity-60">
        {labels.submitReset}
      </button>
    </form>
  );
}
