export function MonthlyChart({ data }: { data: { label: string; value: number }[] }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  const w = 320, h = 140, pad = 24, bw = 28;
  const step = (w - pad * 2) / data.length;
  return (
    <svg viewBox={`0 0 ${w} ${h + 24}`} className="w-full" role="img" aria-label="chart">
      {data.map((d, i) => {
        const bh = (d.value / max) * h;
        const x = pad + i * step + (step - bw) / 2;
        return (
          <g key={d.label + i}>
            <rect x={x} y={h - bh} width={bw} height={Math.max(bh, d.value > 0 ? 2 : 0)} rx="6" fill="#2563FF" />
            <text x={x + bw / 2} y={h - bh - 6} textAnchor="middle" fontSize="11" fill="#0B1B3F">{d.value}</text>
            <text x={x + bw / 2} y={h + 16} textAnchor="middle" fontSize="11" fill="#14295C">{d.label}</text>
          </g>
        );
      })}
      <line x1={pad / 2} x2={w - pad / 2} y1={h} y2={h} stroke="#0B1B3F" strokeOpacity=".1" />
    </svg>
  );
}
