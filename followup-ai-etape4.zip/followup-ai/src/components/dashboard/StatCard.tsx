export function StatCard({ label, value, hint, tone = "default" }: { label: string; value: React.ReactNode; hint?: string; tone?: "default" | "warn" | "good" }) {
  const color = tone === "warn" ? "text-rose-600" : tone === "good" ? "text-emerald-600" : "text-night";
  return (
    <div className="rounded-card bg-white p-5 shadow-card">
      <p className="text-sm text-night-700">{label}</p>
      <div className={`mt-1 text-3xl font-bold ${color}`}>{value}</div>
      {hint && <p className="mt-1 text-xs text-night-700">{hint}</p>}
    </div>
  );
}
