import { LEAD_STATUSES, STATUS_BAR, type LeadStatus } from "@/lib/status";

export function StatusChart({ counts, labels }: { counts: Record<LeadStatus, number>; labels: Record<string, string> }) {
  const max = Math.max(1, ...LEAD_STATUSES.map((s) => counts[s]));
  return (
    <ul className="space-y-3">
      {LEAD_STATUSES.map((s) => (
        <li key={s} className="text-sm">
          <div className="mb-1 flex justify-between"><span>{labels[s]}</span><span className="font-medium">{counts[s]}</span></div>
          <div className="h-2.5 rounded-full bg-mist">
            <div className={`h-2.5 rounded-full ${STATUS_BAR[s]}`} style={{ width: `${(counts[s] / max) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
