/** Début et fin de la journée courante dans un fuseau donné (repli sur UTC si invalide). */
export function dayBounds(tz: string, now = new Date()) {
  let zone = tz;
  try { new Intl.DateTimeFormat("en-US", { timeZone: zone }); } catch { zone = "UTC"; }
  const local = new Date(now.toLocaleString("en-US", { timeZone: zone }));
  const offset = local.getTime() - now.getTime();
  const startLocal = new Date(local);
  startLocal.setHours(0, 0, 0, 0);
  const start = new Date(startLocal.getTime() - offset);
  const end = new Date(start.getTime() + 24 * 3600 * 1000);
  const todayStr = now.toLocaleDateString("en-CA", { timeZone: zone });
  return { start, end, todayStr, zone };
}

/** Les n derniers mois (UTC), du plus ancien au plus récent. */
export function lastMonths(n: number, now = new Date()) {
  const out: { key: string; date: Date }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    out.push({ key: `${d.getUTCFullYear()}-${d.getUTCMonth()}`, date: d });
  }
  return out;
}
