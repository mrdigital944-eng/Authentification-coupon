export function money(amount: number, currency: string, locale: string) {
  try {
    return new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 }).format(amount);
  } catch {
    return `${Math.round(amount)} ${currency}`;
  }
}

/** Somme par devise : aucune conversion, chaque devise reste séparée. */
export function sumByCurrency(rows: { amount: number; currency: string }[]) {
  const m = new Map<string, number>();
  for (const r of rows) m.set(r.currency, (m.get(r.currency) ?? 0) + r.amount);
  return [...m.entries()].map(([currency, amount]) => ({ currency, amount }));
}
