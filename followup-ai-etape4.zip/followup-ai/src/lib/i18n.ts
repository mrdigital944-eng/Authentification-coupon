import { cookies } from "next/headers";

export type Lang = "fr" | "en";
export function getLang(): Lang {
  return cookies().get("lang")?.value === "en" ? "en" : "fr";
}

const dict = {
  fr: {
    nav: { pricing: "Tarifs", login: "Connexion", signup: "Commencer" },
    hero: {
      title: "Ne perdez plus jamais un client.",
      sub: "FollowUp AI centralise vos prospects, programme vos relances et rédige vos messages commerciaux avec l'IA.",
      cta: "Essayer gratuitement",
      cta2: "Voir les tarifs",
    },
    features: [
      ["Prospects centralisés", "Une fiche claire par prospect : contact, statut, notes, prochaine relance."],
      ["Relances fiables", "Programmez vos rappels : le suivi ne dépend plus de votre mémoire."],
      ["Assistant IA", "Rédigez, reformulez et adaptez le ton de vos messages en quelques secondes."],
      ["Historique complet", "Appels, emails, réunions et changements de statut au même endroit."],
    ],
    pricing: { title: "Des tarifs simples", sub: "Commencez gratuitement, évoluez quand vous grandissez.", month: "/mois", free: "Gratuit", choose: "Choisir", start: "Commencer" },
    auth: {
      login: "Connexion", signup: "Créer un compte", forgot: "Mot de passe oublié",
      email: "Adresse email", password: "Mot de passe", name: "Nom complet",
      submitLogin: "Se connecter", submitSignup: "Créer mon compte", submitForgot: "Envoyer le lien",
      forgotLink: "Mot de passe oublié ?", noAccount: "Pas encore de compte ?", haveAccount: "Déjà inscrit ?", back: "Retour à la connexion",
      sentSignup: "Compte créé. Vérifiez votre boîte mail pour confirmer votre adresse.",
      sentForgot: "Si cette adresse existe, un lien de réinitialisation vient d'être envoyé.",
      errConfig: "Le service d'authentification n'est pas encore configuré.",
      errGeneric: "Une erreur est survenue. Vérifiez vos informations.",
      minPwd: "8 caractères minimum.",
      loginOk: "Connexion réussie.",
      newPassword: "Nouveau mot de passe", submitReset: "Enregistrer", resetOk: "Mot de passe mis à jour.",
      suspended: "Ce compte est suspendu.",
    },
    app: {
      logout: "Déconnexion", welcome: "Bienvenue", empty: "Aucun prospect pour le moment. La gestion des prospects arrive à l'étape 5.",
      totalLeads: "Prospects", clients: "Clients", pending: "En attente", today: "Relances du jour", overdue: "Relances en retard",
      conversion: "Taux de conversion", conversionHint: "Convertis / total des prospects", pipeline: "Valeur des opportunités",
      pipelineHint: "Prospects en cours, par devise", overdueInvoices: "Factures en retard", none: "Aucune",
      byStatus: "Prospects par statut", perMonth: "Nouveaux prospects (6 mois)", upcoming: "Relances à traiter", noTasks: "Aucune relance à traiter.",
      late: "En retard",
      status: { new: "Nouveau", contacted: "Contacté", in_discussion: "En discussion", quote_sent: "Devis envoyé", to_follow_up: "À relancer", converted: "Converti", lost: "Perdu" },
    },
    footer: { rights: "Tous droits réservés.", privacy: "Confidentialité", terms: "Conditions" },
    legal: {
      privacyTitle: "Politique de confidentialité",
      privacy: [
        "FollowUp AI collecte les données nécessaires au fonctionnement du service : adresse email, informations de profil et données de prospects que vous saisissez.",
        "Vos données sont stockées dans une base sécurisée et ne sont accessibles qu'aux membres autorisés de votre entreprise.",
        "Nous ne vendons pas vos données. Vous pouvez demander leur suppression à tout moment.",
        "Texte provisoire : à faire valider par un juriste avant le lancement public.",
      ],
      termsTitle: "Conditions d'utilisation",
      terms: [
        "En utilisant FollowUp AI, vous acceptez d'utiliser le service de façon licite et de protéger vos identifiants.",
        "Les formules payantes sont facturées mensuellement ; vous pouvez résilier à tout moment.",
        "Nous pouvons suspendre un compte en cas d'abus ou de non-respect de ces conditions.",
        "Texte provisoire : à faire valider par un juriste avant le lancement public.",
      ],
    },
    plans: {
      FREE: ["5 prospects maximum", "Gestion basique", "Tableau de bord simple"],
      STARTER: ["Gestion avancée des prospects", "Relances", "Historique"],
      PRO: ["Toutes les fonctions Starter", "Assistant IA (selon disponibilité)", "Statistiques avancées", "Modèles de messages"],
      AGENCY: ["Plusieurs équipes", "Plusieurs utilisateurs", "Fonctionnalités avancées"],
    },
  },
  en: {
    nav: { pricing: "Pricing", login: "Log in", signup: "Get started" },
    hero: {
      title: "Never lose a client again.",
      sub: "FollowUp AI centralizes your leads, schedules your follow-ups and writes your sales messages with AI.",
      cta: "Try it free",
      cta2: "See pricing",
    },
    features: [
      ["Centralized leads", "One clear record per lead: contact, status, notes, next follow-up."],
      ["Reliable follow-ups", "Schedule reminders so follow-up no longer depends on memory."],
      ["AI assistant", "Write, rephrase and adjust the tone of your messages in seconds."],
      ["Full history", "Calls, emails, meetings and status changes in one place."],
    ],
    pricing: { title: "Simple pricing", sub: "Start free, upgrade as you grow.", month: "/mo", free: "Free", choose: "Choose", start: "Get started" },
    auth: {
      login: "Log in", signup: "Create an account", forgot: "Forgot password",
      email: "Email address", password: "Password", name: "Full name",
      submitLogin: "Log in", submitSignup: "Create my account", submitForgot: "Send link",
      forgotLink: "Forgot password?", noAccount: "No account yet?", haveAccount: "Already registered?", back: "Back to log in",
      sentSignup: "Account created. Check your inbox to confirm your email.",
      sentForgot: "If this address exists, a reset link has just been sent.",
      errConfig: "The authentication service is not configured yet.",
      errGeneric: "Something went wrong. Check your details.",
      minPwd: "8 characters minimum.",
      loginOk: "Logged in.",
      newPassword: "New password", submitReset: "Save", resetOk: "Password updated.",
      suspended: "This account is suspended.",
    },
    app: {
      logout: "Log out", welcome: "Welcome", empty: "No leads yet. Lead management arrives in step 5.",
      totalLeads: "Leads", clients: "Clients", pending: "Pending", today: "Follow-ups today", overdue: "Overdue follow-ups",
      conversion: "Conversion rate", conversionHint: "Converted / total leads", pipeline: "Opportunity value",
      pipelineHint: "Open leads, per currency", overdueInvoices: "Overdue invoices", none: "None",
      byStatus: "Leads by status", perMonth: "New leads (6 months)", upcoming: "Follow-ups to handle", noTasks: "No follow-ups to handle.",
      late: "Overdue",
      status: { new: "New", contacted: "Contacted", in_discussion: "In discussion", quote_sent: "Quote sent", to_follow_up: "To follow up", converted: "Converted", lost: "Lost" },
    },
    footer: { rights: "All rights reserved.", privacy: "Privacy", terms: "Terms" },
    legal: {
      privacyTitle: "Privacy policy",
      privacy: [
        "FollowUp AI collects the data needed to run the service: email address, profile details and the lead data you enter.",
        "Your data is stored in a secured database and is only accessible to authorized members of your company.",
        "We do not sell your data. You can request deletion at any time.",
        "Draft text: have a lawyer review it before the public launch.",
      ],
      termsTitle: "Terms of use",
      terms: [
        "By using FollowUp AI, you agree to use the service lawfully and to protect your credentials.",
        "Paid plans are billed monthly; you can cancel at any time.",
        "We may suspend an account in case of abuse or breach of these terms.",
        "Draft text: have a lawyer review it before the public launch.",
      ],
    },
    plans: {
      FREE: ["Up to 5 leads", "Basic management", "Simple dashboard"],
      STARTER: ["Advanced lead management", "Follow-ups", "History"],
      PRO: ["All Starter features", "AI assistant (subject to availability)", "Advanced statistics", "Message templates"],
      AGENCY: ["Multiple teams", "Multiple users", "Advanced features"],
    },
  },
} as const;

export function t(lang: Lang) {
  return dict[lang];
}
