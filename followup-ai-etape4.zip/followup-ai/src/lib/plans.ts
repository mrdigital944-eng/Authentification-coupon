export const PLANS = [
  { id: "FREE", price: 0 },
  { id: "STARTER", price: 7 },
  { id: "PRO", price: 15, highlight: true },
  { id: "AGENCY", price: 29 },
] as const;
export type PlanId = (typeof PLANS)[number]["id"];
