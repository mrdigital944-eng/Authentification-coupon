export const LEAD_STATUSES = ["new", "contacted", "in_discussion", "quote_sent", "to_follow_up", "converted", "lost"] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const PENDING_STATUSES: LeadStatus[] = ["new", "contacted", "in_discussion", "quote_sent", "to_follow_up"];

export const STATUS_BAR: Record<LeadStatus, string> = {
  new: "bg-slate-400",
  contacted: "bg-sky-400",
  in_discussion: "bg-electric",
  quote_sent: "bg-indigo-500",
  to_follow_up: "bg-amber-500",
  converted: "bg-emerald-500",
  lost: "bg-rose-400",
};
