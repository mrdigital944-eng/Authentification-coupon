-- FollowUp AI : schéma initial (étape 3)
create extension if not exists pgcrypto;

create type lead_status as enum ('new','contacted','in_discussion','quote_sent','to_follow_up','converted','lost');
create type member_role as enum ('owner','admin','member');
create type plan_id as enum ('FREE','STARTER','PRO','AGENCY');
create type interaction_type as enum ('call','email','meeting','message','note','status_change');
create type task_status as enum ('pending','done','snoozed');
create type invoice_status as enum ('draft','sent','paid','overdue','cancelled');

create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  lang text not null default 'fr' check (lang in ('fr','en')),
  timezone text not null default 'UTC',
  role text not null default 'user' check (role in ('user','admin')),
  suspended boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid not null references auth.users(id) on delete cascade,
  default_currency char(3) not null default 'USD',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table memberships (
  company_id uuid not null references companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role member_role not null default 'member',
  created_at timestamptz not null default now(),
  primary key (company_id, user_id)
);
create index on memberships (user_id);

create table leads (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  name text not null check (length(name) between 1 and 200),
  company_name text,
  email text,
  phone text,
  status lead_status not null default 'new',
  notes text,
  estimated_value numeric(14,2) check (estimated_value >= 0),
  currency char(3) not null default 'USD',
  last_contact_at timestamptz,
  next_follow_up_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on leads (company_id, status);
create index on leads (company_id, next_follow_up_at);

create table clients (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  lead_id uuid references leads(id) on delete set null,
  name text not null check (length(name) between 1 and 200),
  company_name text,
  email text,
  phone text,
  category text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on clients (company_id);

create table invoices (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  client_id uuid references clients(id) on delete set null,
  number text not null,
  amount numeric(14,2) not null check (amount >= 0),
  currency char(3) not null default 'USD',
  due_date date not null,
  status invoice_status not null default 'sent',
  paid_at timestamptz,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, number)
);
create index on invoices (company_id, status, due_date);

create table tasks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  lead_id uuid references leads(id) on delete cascade,
  client_id uuid references clients(id) on delete cascade,
  invoice_id uuid references invoices(id) on delete cascade,
  assigned_to uuid references auth.users(id),
  title text not null check (length(title) between 1 and 200),
  description text,
  due_at timestamptz not null,
  status task_status not null default 'pending',
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on tasks (company_id, status, due_at);

create table interactions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  lead_id uuid references leads(id) on delete cascade,
  client_id uuid references clients(id) on delete cascade,
  type interaction_type not null,
  content text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index on interactions (company_id, created_at desc);

create table message_templates (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  name text not null,
  channel text not null default 'email' check (channel in ('email','whatsapp','sms')),
  tone text not null default 'professional' check (tone in ('professional','friendly','persuasive','short')),
  lang text not null default 'fr' check (lang in ('fr','en')),
  body text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on message_templates (company_id);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  company_id uuid references companies(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index on notifications (user_id, read_at, created_at desc);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null unique references companies(id) on delete cascade,
  plan plan_id not null default 'FREE',
  status text not null default 'active' check (status in ('active','past_due','canceled')),
  provider text,
  provider_ref text,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table payments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  subscription_id uuid references subscriptions(id) on delete set null,
  amount numeric(14,2) not null,
  currency char(3) not null,
  provider text not null,
  provider_ref text not null,
  status text not null check (status in ('pending','succeeded','failed','refunded')),
  created_at timestamptz not null default now(),
  unique (provider, provider_ref)
);
create index on payments (company_id, created_at desc);

create table audit_logs (
  id bigint generated always as identity primary key,
  company_id uuid references companies(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity text,
  entity_id uuid,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index on audit_logs (company_id, created_at desc);

-- updated_at
do $$ declare t text; begin
  foreach t in array array['profiles','companies','leads','clients','invoices','tasks','message_templates','subscriptions'] loop
    execute format('create trigger trg_%I_updated before update on %I for each row execute function set_updated_at()', t, t);
  end loop;
end $$;

-- Fonctions d'autorisation
create or replace function is_member(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships m where m.company_id = cid and m.user_id = auth.uid())
$$;

create or replace function is_company_admin(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships m where m.company_id = cid and m.user_id = auth.uid() and m.role in ('owner','admin'))
$$;

create or replace function is_platform_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin' and not p.suspended)
$$;

-- Création automatique du profil, de l'entreprise et de l'abonnement FREE
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare cid uuid; nm text;
begin
  nm := coalesce(new.raw_user_meta_data->>'full_name', '');
  insert into profiles (id, full_name) values (new.id, nm);
  insert into companies (name, owner_id) values (coalesce(nullif(nm, ''), split_part(new.email, '@', 1)), new.id) returning id into cid;
  insert into memberships (company_id, user_id, role) values (cid, new.id, 'owner');
  insert into subscriptions (company_id, plan, status) values (cid, 'FREE', 'active');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Limite du plan FREE : 5 prospects
create or replace function enforce_lead_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare p plan_id; n int;
begin
  select plan into p from subscriptions where company_id = new.company_id;
  if coalesce(p, 'FREE') = 'FREE' then
    select count(*) into n from leads where company_id = new.company_id;
    if n >= 5 then raise exception 'plan_limit_leads' using errcode = 'P0001'; end if;
  end if;
  return new;
end $$;
create trigger trg_leads_limit before insert on leads for each row execute function enforce_lead_limit();

-- Row Level Security
alter table profiles enable row level security;
alter table companies enable row level security;
alter table memberships enable row level security;
alter table leads enable row level security;
alter table clients enable row level security;
alter table invoices enable row level security;
alter table tasks enable row level security;
alter table interactions enable row level security;
alter table message_templates enable row level security;
alter table notifications enable row level security;
alter table subscriptions enable row level security;
alter table payments enable row level security;
alter table audit_logs enable row level security;

create policy profiles_select on profiles for select using (id = auth.uid() or is_platform_admin());
create policy profiles_update on profiles for update using (id = auth.uid()) with check (id = auth.uid());
-- Un utilisateur ne peut modifier que son nom, sa langue et son fuseau (pas role ni suspended)
revoke update on profiles from authenticated, anon;
grant update (full_name, lang, timezone) on profiles to authenticated;

create policy companies_select on companies for select using (is_member(id) or is_platform_admin());
create policy companies_update on companies for update using (is_company_admin(id)) with check (is_company_admin(id));

create policy memberships_select on memberships for select using (user_id = auth.uid() or is_member(company_id) or is_platform_admin());

do $$ declare t text; begin
  foreach t in array array['leads','clients','invoices','tasks','interactions','message_templates'] loop
    execute format('create policy %I_all on %I for all using (is_member(company_id)) with check (is_member(company_id))', t, t);
  end loop;
end $$;

create policy notifications_select on notifications for select using (user_id = auth.uid());
create policy notifications_update on notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Abonnements et paiements : lecture seule pour les membres, écriture par le serveur (service role) uniquement
create policy subscriptions_select on subscriptions for select using (is_member(company_id) or is_platform_admin());
create policy payments_select on payments for select using (is_company_admin(company_id) or is_platform_admin());

create policy audit_select on audit_logs for select using (is_company_admin(company_id) or is_platform_admin());
create policy audit_insert on audit_logs for insert with check (user_id = auth.uid() and (company_id is null or is_member(company_id)));
