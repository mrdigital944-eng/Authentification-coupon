-- DONNÉES DE DÉMO (développement uniquement, ne pas lancer en production).
-- Remplacez l'email puis exécutez dans le SQL Editor de Supabase.
do $$
declare uid uuid; cid uuid;
begin
  select id into uid from auth.users where email = 'VOTRE_EMAIL';
  if uid is null then raise exception 'Utilisateur introuvable'; end if;
  select company_id into cid from memberships where user_id = uid limit 1;

  -- Passe l'abonnement en PRO pour dépasser la limite de 5 prospects du plan FREE (test seulement)
  update subscriptions set plan = 'PRO' where company_id = cid;

  insert into leads (company_id, name, company_name, status, estimated_value, currency, created_at) values
    (cid, 'Awa Diallo', 'Boutique Awa', 'new', 800, 'USD', now() - interval '10 days'),
    (cid, 'Marc Dupont', 'Dupont SARL', 'contacted', 1500, 'EUR', now() - interval '40 days'),
    (cid, 'Fatou Ndiaye', 'Fatou Design', 'in_discussion', 600000, 'XAF', now() - interval '70 days'),
    (cid, 'John Smith', 'Smith & Co', 'quote_sent', 2200, 'USD', now() - interval '100 days'),
    (cid, 'Léa Martin', 'Studio Léa', 'to_follow_up', 900, 'EUR', now() - interval '5 days'),
    (cid, 'Paul Biya Jr', 'PB Services', 'converted', 3000, 'USD', now() - interval '30 days'),
    (cid, 'Sam Lee', 'Lee Agency', 'lost', 500, 'USD', now() - interval '20 days');

  insert into tasks (company_id, title, due_at) values
    (cid, 'Rappeler Awa Diallo', now() - interval '2 days'),
    (cid, 'Envoyer le devis à Léa', now() + interval '1 hour');

  insert into invoices (company_id, number, amount, currency, due_date, status) values
    (cid, 'F-001', 450, 'USD', current_date - 12, 'sent'),
    (cid, 'F-002', 300000, 'XAF', current_date - 3, 'sent');
end $$;
