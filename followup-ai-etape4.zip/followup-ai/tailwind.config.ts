import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        night: { DEFAULT: "#0B1B3F", 700: "#14295C" },
        electric: { DEFAULT: "#2563FF", 600: "#1D4FD8" },
        mist: "#F5F7FA",
      },
      borderRadius: { card: "14px" },
      boxShadow: { card: "0 1px 2px rgba(11,27,63,.06), 0 4px 12px rgba(11,27,63,.05)" },
    },
  },
  plugins: [],
};
export default config;
